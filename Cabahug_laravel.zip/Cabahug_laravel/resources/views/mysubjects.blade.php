@extends('layouts.app2')

@section("content")
<!DOCTYPE html>
<html>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">   
          <h1>MY ACADEMIC SCHEDULE</h1>
              <div class="panel panel-default">
              	<H3>
              	<table style="width:100%" border="1">
				  <tr>
				    <th>SUBJECT NAME</th>
				    <th>DAYS & TIME</th> 
				    <th>PROFESSOR</th>
				  </tr>
				  <tr>
				  <td>Sociology</td>
				  <td>MWF - 5:30 - 6:30 </td> 
				  <td>MR.Unknown</td>
				  </tr>
				  <tr>
				    <td>ITELECPHP2</td>
				    <td>MWF - 6:30 - 8:30</td>
				    <td>MR. GIAN CARLO CATARAJA</td>
				  </tr>
				 
				    <tr>
				    <td>PRACTICUM 42</td>
				    <td>MWF- 2:30- 3:30</td>
				    <td>DR. MELVIN M. NIÑAL</td>
				  </tr>
				    <tr>
				    <td>CAPSTONE 41</td>
				    <td>MWF- 7:30- 8:30</td>
				    <td>DR. MELVIN M. NIÑAL</td>
				  </tr>
				</table>
				</H3>
              </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
@stop