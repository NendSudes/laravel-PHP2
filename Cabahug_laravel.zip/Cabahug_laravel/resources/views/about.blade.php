@extends('layouts.app2')

@section("content")
    <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        	<h1>ALL ABOUT ME</h1>

              <div class="panel panel-default">
              	<H5>
  				  I Am Cabahug, Carl Cesar.<BR><BR>
  				  I am currently residing at Banawa, Capaculan, Cebu.<BR><BR>
  				  I am the 3rd among 5 siblings.<BR><BR>
            I am aged 20 and will be 21 this December<BR><BR>
  				  I was born in Dalaguete, Obo.<BR><BR>
  				  I am still single and might never find a GF since I am a wizard.<BR><BR>
  				  I have no work, but I can work, maybe .<BR><BR>
            When I am alone at home I make memes, it always reaches hot page too<BR><BR>s
  				  Even so, I am continuing my studies and hope to graduate early.<BR><BR>
  				  Education was created in order for people not to starve to death.<BR><BR>
  				  My goal for now is to graduate, have a job, and eat lots.<BR><BR>
            My hobbies is about any person in the technology world would do, browsing on cellphone and play on PC<BR><BR>
  				  When it comes to work, I am a beginner. <BR><BR>
  				  I am able to work with less speed, no accuracy but can work under no gravity.<BR><BR>
  				  I am highly dedicated and persevering with a positive attitude.<BR><BR>
  				  I can be tamed and able to work with a lot of supervision.<BR><BR>
  				  I am a bit mature, and have horrible personality. <BR><BR>
  				  I can work with any horrible team.<BR><BR>
  				  Because of these reasons that I am confident that I can have a slightly bright future ahead of me and<BR><BR>
  				  I am looking forward to the hurdles and mistakes in advance.
              </H5>
              </div>
            </div>
        </div>
    </div>
</div>

@stop