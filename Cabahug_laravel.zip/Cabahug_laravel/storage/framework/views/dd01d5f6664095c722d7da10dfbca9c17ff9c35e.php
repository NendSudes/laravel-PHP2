<?php $__env->startSection("content"); ?>
    <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        	<h1>ABOUT MY EDUCATION</h1>

              <div class="panel panel-default">
              	<H3>
  				Elementary : Maydolong Elementary School <BR><BR>
  				High School : Pitalo National High School<BR><BR>
  				College : University Of Cebu – Main Campus (Present) <BR>
  				Course : Bachelor of Science in Information Technology<BR><BR>
  				Pipe Fitting Fabrication- TESDA, NAGA, Cebu
              </H3>
              </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>