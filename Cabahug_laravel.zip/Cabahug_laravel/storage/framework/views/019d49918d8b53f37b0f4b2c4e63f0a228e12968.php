<?php $__env->startSection("content"); ?>
<!DOCTYPE html>
<html>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">   
          <h1>MY ACADEMIC SCHEDULE</h1>
              <div class="panel panel-default">
              	<H3>
              	<table style="width:100%" border="1">
				  <tr>
				    <th>SUBJECT NAME</th>
				    <th>DAYS & TIME</th> 
				    <th>PROFESSOR</th>
				  </tr>
				  <tr>
				  <td>ITELECIOS</td>
				  <td>MWF - 1:30 - 3:30 </td> 
				  <td>MR.DENNIS DURANO</td>
				  </tr>
				  <tr>
				    <td>ITELECPHP2</td>
				    <td>MWF - 6:30 - 8:30</td>
				    <td>MR. GIAN CARLO CATARAJA</td>
				  </tr>
				  <tr>
				    <td>PHYSICS 2H</td>
				    <td>TTH-3:00-6:30</td>
				    <td>MR. DANILO LARONA</td>
				  </tr>
				    <tr>
				    <td>PRACTICUM 42</td>
				    <td>MWF- 5:30- 9:30</td>
				    <td>DR. MELVIN M. NIÑAL</td>
				  </tr>
				    <tr>
				    <td>CAPSTONE 42</td>
				    <td>SAT- 12:30- 5:30</td>
				    <td>DR. MELVIN M. NIÑAL</td>
				  </tr>
				</table>
				</H3>
              </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>